function calculateTotal() {
    let checkboxes = document.querySelectorAll('input[name="courses"]:checked');
    let total = 0;
    let discount = 0;
    
    checkboxes.forEach((checkbox) => {
        total += parseInt(checkbox.value);
    });

    // Apply discount logic
    if (checkboxes.length > 1 && checkboxes.length < 4) {
        discount = 10;
    } else if (checkboxes.length >= 4) {
        discount = 15;
    }
    
    let finalTotal = total - (total * (discount / 100));
    document.getElementById('total').innerText = `Total after discount: R${finalTotal}`;
}
